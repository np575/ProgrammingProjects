package com.example.orientationtimezone

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Surface
import kotlinx.android.synthetic.main.activity_main.*
import java.text.SimpleDateFormat;
import java.util.*
import java.util.TimeZone;

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val rotation = getWindowManager().getDefaultDisplay().getRotation()

        Log.d("mylog", rotation.toString());

        fun Rotate_Device(): Int {

           // Log.d("mylog", rotation.toString());
            when (rotation) {
                Surface.ROTATION_0 -> return 0
                Surface.ROTATION_90 -> return 90
                Surface.ROTATION_180 -> return 180
                Surface.ROTATION_270 -> return 270
            }

            return 0
        }
       // SimpleDateFormat date_format = new SimpleDateFormat("dd-MM-YYYY EEEE hh:mm:ss a");

        if (Rotate_Device() == 0) {
            val timezone = TimeZone.getTimeZone("GMT-4").getID()
            val city = "Newark"
            val zone = TimeZone.getTimeZone("GMT-04:00")
            val time = Calendar.getInstance(zone);
            val time_format = String.format("%02d" , time.get(Calendar.HOUR_OF_DAY))+":"+String.format("%02d" , time.get(Calendar.MINUTE))+":"+String.format("%02d" , time.get(Calendar.SECOND));
            textView1.text = " $timezone | $city |  $time_format"
        } else if(Rotate_Device() == 270) {
            val timezone = TimeZone.getTimeZone("GMT+1").getID()
            val city = "Paris"
            val zone = TimeZone.getTimeZone("GMT+01:00")
            val time = Calendar.getInstance(zone);
            val time_format = String.format("%02d" , time.get(Calendar.HOUR_OF_DAY))+":"+String.format("%02d" , time.get(Calendar.MINUTE))+":"+String.format("%02d" , time.get(Calendar.SECOND));
            textView1.text = " $timezone | $city |  $time_format"
        } else if (Rotate_Device() == 90) {
            val timezone = TimeZone.getTimeZone("GMT-8").getID()
            val city = "Los Angeles"
            val zone = TimeZone.getTimeZone("GMT-07:00")
            val time = Calendar.getInstance(zone);
            val time_format = String.format("%02d" , time.get(Calendar.HOUR_OF_DAY))+":"+String.format("%02d" , time.get(Calendar.MINUTE))+":"+String.format("%02d" , time.get(Calendar.SECOND));
            textView1.text = " $timezone | $city |  $time_format"
        }



    }
}