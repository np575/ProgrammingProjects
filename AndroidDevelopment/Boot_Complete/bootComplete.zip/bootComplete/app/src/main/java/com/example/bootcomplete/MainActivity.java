package com.example.bootcomplete;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Toast toast,toast1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("BOOT", "Hello World!");
        toast1=Toast.makeText(this,"App just Started",toast.LENGTH_SHORT);
        toast1.show();
        toast=Toast.makeText(this,"Boot completed",toast.LENGTH_SHORT);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                    try {
                        Thread.sleep(30000);
                        toast.show();

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

            }

        });

        Thread m = new Thread(new Runnable() {
            @Override
            public void run() {

                    try {
                        Thread.sleep(45000);
                        String uri = String.format(Locale.ENGLISH,"geo:");
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setPackage("com.google.android.apps.maps");
                        startActivity(intent);

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }

        });
        t.start();
        m.start();
    }
}