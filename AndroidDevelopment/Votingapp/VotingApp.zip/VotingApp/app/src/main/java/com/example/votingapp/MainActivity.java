package com.example.votingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference reference = database.getReference("Voting");
    boolean flag = true;
    String blueDB, greenDB, redDB, yellowDB;
    int blueInc, redInc, greenInc, yellowInc;

    int blue =0;
    int red = 0;
    int green = 0;
    int yellow = 0;
    TextView textView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.output);
    }

    public void Start(View v){
        flag = true;
        new VotingResults().execute();
    }

    public void Stop(View v){
        flag = false;
        new stopButton().execute();
    }



    private class VotingResults extends AsyncTask<Integer, Integer, Integer>{

        @Override
        protected Integer doInBackground(Integer... integers) {

            if (blue == 0 || green ==0 || red == 0 || yellow == 0){
                blue = ((int) (Math.random() * (5000 - 100) )) + 100;
                green = ((int) (Math.random() * (5000 - 100) )) + 100;
                red = ((int) (Math.random() * (5000 - 100) )) + 100;
                yellow = ((int) (Math.random() * (5000 - 100) )) + 100;

                reference.child("Blue").setValue(blue);
                reference.child("Green").setValue(green);
                reference.child("Red").setValue(red);
                reference.child("Yellow").setValue(yellow);
            }

            while(flag){

                blueInc = ((int) (Math.random() * (1000 - 100) )) + 100;
                greenInc = ((int) (Math.random() * (1000 - 100) )) + 100;
                redInc = ((int) (Math.random() * (1000 - 100) )) + 100;
                yellowInc = ((int) (Math.random() * (1000 - 100) )) + 100;

                blue += blueInc;
                green += greenInc;
                red += redInc;
                yellow += yellowInc;

                reference.child("Blue").setValue(blue);
                reference.child("Green").setValue(green);
                reference.child("Red").setValue(red);
                reference.child("Yellow").setValue(yellow);

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }

    private class stopButton extends AsyncTask<Integer, Integer, Integer>{

        @Override
        protected Integer doInBackground(Integer... integers) {
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    blueDB = snapshot.child("Blue").getValue().toString();
                    greenDB = snapshot.child("Green").getValue().toString();
                    redDB = snapshot.child("Red").getValue().toString();
                    yellowDB = snapshot.child("Yellow").getValue().toString();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            return null;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            textView.setText("Number of Votes per Party: \n"+"Blue: "+blueDB +"\nGreen: " + greenDB +"\nRed: " + redDB + "\nYellow: " + yellowDB);

        }
    }


}